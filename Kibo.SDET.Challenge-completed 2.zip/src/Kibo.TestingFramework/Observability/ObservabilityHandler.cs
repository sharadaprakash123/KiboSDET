using System.Diagnostics;
using System.Text;

namespace Kibo.TestingFramework.Observability;

/// <summary>
/// A <see cref="DelegatingHandler"/> that instruments every outgoing HTTP request with:
///   1. A unique correlation id (sent as the <c>X-Kibo-Correlation-Id</c> header).
///   2. Elapsed-time capture (always active — it's cheap).
///   3. Request/response logging (method, URL, headers, body) — captured on every call,
///      but only printed to the console when <see cref="EnableConsoleLogging"/> is true.
///
/// The captured diagnostics are exposed back to the caller via custom response headers
/// (<c>X-Kibo-Correlation-Id</c>, <c>X-Kibo-Elapsed-Ms</c>, <c>X-Kibo-Request-Log</c>,
/// <c>X-Kibo-Response-Log</c>) so that <see cref="Client.ApiClient"/> can build a rich
/// <see cref="ApiResponse{T}"/> without any additional plumbing.
/// </summary>
public class ObservabilityHandler : DelegatingHandler
{
    /// <summary>
    /// Maximum number of characters of a request/response body to include in the
    /// human-readable log before truncating. Keeps log output bounded for large payloads.
    /// </summary>
    private const int MaxLogBodyLength = 100;

    /// <summary>
    /// When true, every captured request/response log line is also written to the
    /// console as it happens. Off by default for clean test output; the diagnostics
    /// are still captured and attached to the response either way.
    ///
    /// Toggle via the <c>KIBO_TEST_LOGGING=true</c> environment variable, or by
    /// setting this property directly (e.g. from a test fixture).
    /// </summary>
    public bool EnableConsoleLogging { get; set; } =
        string.Equals(Environment.GetEnvironmentVariable("KIBO_TEST_LOGGING"), "true", StringComparison.OrdinalIgnoreCase);

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var correlationId = Guid.NewGuid().ToString("N")[..8];
        request.Headers.TryAddWithoutValidation("X-Kibo-Correlation-Id", correlationId);

        var requestLog = await BuildRequestLogAsync(request, correlationId);

        var stopwatch = Stopwatch.StartNew();
        var response = await base.SendAsync(request, cancellationToken);
        stopwatch.Stop();
        var elapsedMs = stopwatch.ElapsedMilliseconds;

        var responseLog = await BuildResponseLogAsync(response, correlationId, elapsedMs);

        if (EnableConsoleLogging)
        {
            Console.WriteLine(requestLog);
            Console.WriteLine(responseLog);
        }

        // Attach diagnostics so ApiClient can read them back off the response,
        // without needing a shared/mutable side-channel.
        response.Headers.Add("X-Kibo-Correlation-Id", correlationId);
        response.Headers.Add("X-Kibo-Elapsed-Ms", elapsedMs.ToString());
        response.Headers.Add("X-Kibo-Request-Log", EncodeHeaderValue(requestLog));
        response.Headers.Add("X-Kibo-Response-Log", EncodeHeaderValue(responseLog));

        return response;
    }

    private static async Task<string> BuildRequestLogAsync(HttpRequestMessage request, string correlationId)
    {
        var sb = new StringBuilder();
        sb.Append($"[{correlationId}] → {request.Method} {request.RequestUri}");

        var headers = request.Headers
            .Where(h => !string.Equals(h.Key, "X-Kibo-Correlation-Id", StringComparison.OrdinalIgnoreCase))
            .Select(h => $"{h.Key}: {string.Join(",", h.Value)}");
        if (headers.Any())
        {
            sb.Append($" | headers: {{{string.Join(", ", headers)}}}");
        }

        if (request.Content is not null)
        {
            var body = await request.Content.ReadAsStringAsync();
            sb.Append($" | body: {Truncate(body)}");
        }

        return sb.ToString();
    }

    private static async Task<string> BuildResponseLogAsync(
        HttpResponseMessage response, string correlationId, long elapsedMs)
    {
        var body = await response.Content.ReadAsStringAsync();

        return $"[{correlationId}] ← {(int)response.StatusCode} {response.StatusCode} " +
               $"({elapsedMs} ms) | body: {Truncate(body)}";
    }

    /// <summary>
    /// Truncates a body string to <see cref="MaxLogBodyLength"/> characters so
    /// large payloads don't blow up log output, and collapses newlines so the
    /// log stays on one line.
    /// </summary>
    private static string Truncate(string body)
    {
        var collapsed = body.Replace("\r", "").Replace("\n", " ").Trim();
        return collapsed.Length <= MaxLogBodyLength
            ? collapsed
            : collapsed[..MaxLogBodyLength] + "...(truncated)";
    }

    /// <summary>
    /// HTTP header values can't contain newlines/control characters. Our log strings
    /// are already single-line (see <see cref="Truncate"/>), but as a defensive
    /// measure we strip any remaining characters that would make the header value invalid.
    /// </summary>
    private static string EncodeHeaderValue(string value)
    {
        return value.Replace("\r", "").Replace("\n", " ");
    }
}
