using System.Net;

namespace Kibo.TestingFramework.Observability;

/// <summary>
/// Wraps the result of an API call along with diagnostic information
/// (status code, timing, correlation id, and human-readable request/response logs).
///
/// This is the core of Task 6: every call made through <see cref="Client.ApiClient"/>
/// returns one of these, so that when an assertion on <see cref="StatusCode"/> or
/// <see cref="Body"/> fails, the test output can immediately include
/// <see cref="RequestLog"/> / <see cref="ResponseLog"/> / <see cref="CorrelationId"/>
/// without re-running anything.
/// </summary>
/// <typeparam name="T">The deserialized response body type.</typeparam>
public class ApiResponse<T>
{
    /// <summary>The HTTP status code returned by the server.</summary>
    public HttpStatusCode StatusCode { get; init; }

    /// <summary>The deserialized response body, or default(T) if deserialization was skipped/failed.</summary>
    public T? Body { get; init; }

    /// <summary>The raw response body as a string (always available, even if deserialization fails).</summary>
    public string RawBody { get; init; } = string.Empty;

    /// <summary>Elapsed time for the HTTP call, in milliseconds. Always captured.</summary>
    public long ElapsedMs { get; init; }

    /// <summary>
    /// Per-call correlation id (also sent to the server via the
    /// <c>X-Kibo-Correlation-Id</c> header) so requests can be traced through logs.
    /// </summary>
    public string CorrelationId { get; init; } = string.Empty;

    /// <summary>
    /// Human-readable summary of the outgoing request
    /// (method, URL, headers, body). Populated regardless of the
    /// logging toggle so it's available on test failure.
    /// </summary>
    public string RequestLog { get; init; } = string.Empty;

    /// <summary>
    /// Human-readable summary of the incoming response
    /// (status code, headers, body). Populated regardless of the
    /// logging toggle so it's available on test failure.
    /// </summary>
    public string ResponseLog { get; init; } = string.Empty;

    /// <summary>
    /// Convenience flag for 2xx status codes.
    /// </summary>
    public bool IsSuccess => (int)StatusCode is >= 200 and < 300;

    /// <summary>
    /// Builds a single multi-line diagnostic block combining everything
    /// needed to debug a failure: correlation id, timing, request, and response.
    /// Intended to be dumped via Console.WriteLine / test output on assertion failure.
    /// </summary>
    public string ToDiagnosticString()
    {
        return $"""
                ── Diagnostics [{CorrelationId}] ({ElapsedMs} ms) ──
                {RequestLog}
                {ResponseLog}
                ───────────────────────────────────────────────────
                """;
    }
}
