using System.Text;
using System.Text.Json;
using Kibo.TestingFramework.Models;
using Kibo.TestingFramework.Observability;

namespace Kibo.TestingFramework.Client;

/// <summary>
/// Reusable API client for the Kibo Mock Fulfillment API.
///
/// Responsibilities (Task 1):
///   - Owns a single shared <see cref="HttpClient"/> instance (correct lifecycle/disposal).
///   - Base URL is externalized via the <c>KIBO_API_BASE_URL</c> environment variable,
///     falling back to <c>http://localhost:5000</c> for local dev.
///   - Centralizes the <c>x-kibo-tenant</c> header and JSON serialization/deserialization.
///
/// Responsibilities (Task 6):
///   - Every call is routed through <see cref="ObservabilityHandler"/>, which attaches
///     a correlation id, timing, and request/response logs to the HTTP response headers.
///   - Those diagnostics are unpacked into a typed <see cref="ApiResponse{T}"/> so tests
///     get rich, self-diagnosing failures without re-running anything.
/// </summary>
public sealed class ApiClient : IDisposable
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _httpClient;
    private readonly ObservabilityHandler _observabilityHandler;

    /// <summary>
    /// Default tenant id sent via the <c>x-kibo-tenant</c> header on every request,
    /// unless overridden per-call (see <see cref="CreateOrderAsync"/>) or via
    /// <see cref="WithoutTenantHeader"/>.
    /// </summary>
    public string? DefaultTenantId { get; }

    /// <summary>The base URL all requests are issued against.</summary>
    public string BaseUrl { get; }

    /// <summary>
    /// Enables or disables console logging of request/response diagnostics.
    /// Off by default; can also be toggled via the <c>KIBO_TEST_LOGGING=true</c>
    /// environment variable. Timing/correlation capture is unaffected by this flag.
    /// </summary>
    public bool EnableConsoleLogging
    {
        get => _observabilityHandler.EnableConsoleLogging;
        set => _observabilityHandler.EnableConsoleLogging = value;
    }

    /// <summary>
    /// Creates a new <see cref="ApiClient"/>.
    /// </summary>
    /// <param name="baseUrl">
    /// Base URL of the Kibo Mock API. If null, falls back to the
    /// <c>KIBO_API_BASE_URL</c> environment variable, then to
    /// <c>http://localhost:5000</c>.
    /// </param>
    /// <param name="defaultTenantId">
    /// Tenant id sent via <c>x-kibo-tenant</c> on every request by default.
    /// Pass null to omit the header entirely (e.g. to test the 401 path).
    /// </param>
    public ApiClient(string? baseUrl = null, string? defaultTenantId = "tenant-abc-123")
    {
        BaseUrl = baseUrl
                  ?? Environment.GetEnvironmentVariable("KIBO_API_BASE_URL")
                  ?? "http://localhost:5000";

        DefaultTenantId = defaultTenantId;

        _observabilityHandler = new ObservabilityHandler
        {
            InnerHandler = new HttpClientHandler()
        };

        _httpClient = new HttpClient(_observabilityHandler)
        {
            BaseAddress = new Uri(BaseUrl)
        };
    }

    /// <summary>
    /// Creates a new client configured for a specific tenant. Useful for tests
    /// that need a one-off tenant value (e.g. security/edge-case tests) without
    /// affecting the shared default client.
    /// </summary>
    public static ApiClient CreateClientWithTenant(string tenantId, string? baseUrl = null)
        => new(baseUrl, tenantId);

    /// <summary>
    /// Creates a new client with no <c>x-kibo-tenant</c> header at all, e.g. to
    /// exercise the 401 Unauthorized path.
    /// </summary>
    public static ApiClient WithoutTenantHeader(string? baseUrl = null)
        => new(baseUrl, defaultTenantId: null);

    /// <summary>
    /// POST /v1/orders — creates a new order.
    /// </summary>
    /// <param name="order">The order payload (CustomerEmail + LineItems are sent).</param>
    /// <param name="tenantId">
    /// Overrides the client's default tenant for this call only.
    /// </param>
    public Task<ApiResponse<Order>> CreateOrderAsync(Order order, string? tenantId = null)
    {
        var json = JsonSerializer.Serialize(new
        {
            customerEmail = order.CustomerEmail,
            lineItems = order.LineItems
        }, JsonOptions);

        return SendAsync<Order>(HttpMethod.Post, "/v1/orders", json, tenantId);
    }

    /// <summary>
    /// POST /v1/orders using a raw JSON body — used by edge-case tests that need
    /// to send intentionally malformed/oversized/invalid payloads that wouldn't
    /// round-trip through the <see cref="Order"/> model.
    /// </summary>
    public Task<ApiResponse<Order>> CreateOrderRawAsync(string rawJson, string? tenantId = null)
        => SendAsync<Order>(HttpMethod.Post, "/v1/orders", rawJson, tenantId);

    /// <summary>
    /// GET /v1/orders/{id} — fetches the current state of an order.
    /// </summary>
    public Task<ApiResponse<Order>> GetOrderAsync(Guid id, string? tenantId = null)
        => SendAsync<Order>(HttpMethod.Get, $"/v1/orders/{id}", body: null, tenantId);

    private async Task<ApiResponse<T>> SendAsync<T>(
        HttpMethod method, string path, string? body, string? tenantId)
    {
        using var request = new HttpRequestMessage(method, path);

        // Resolve which tenant header (if any) to apply for this call.
        var effectiveTenant = tenantId ?? DefaultTenantId;
        if (!string.IsNullOrEmpty(effectiveTenant))
        {
            request.Headers.TryAddWithoutValidation("x-kibo-tenant", effectiveTenant);
        }

        if (body is not null)
        {
            request.Content = new StringContent(body, Encoding.UTF8, "application/json");
        }

        var httpResponse = await _httpClient.SendAsync(request);
        return await BuildApiResponseAsync<T>(httpResponse);
    }

    /// <summary>
    /// Reads the diagnostic headers attached by <see cref="ObservabilityHandler"/>
    /// and the response body, then assembles the typed <see cref="ApiResponse{T}"/>.
    /// Deserialization failures (e.g. error-shaped bodies on 4xx/5xx) are tolerated —
    /// <see cref="ApiResponse{T}.Body"/> is simply left as default in that case,
    /// while <see cref="ApiResponse{T}.RawBody"/> always retains the raw text.
    /// </summary>
    private static async Task<ApiResponse<T>> BuildApiResponseAsync<T>(HttpResponseMessage httpResponse)
    {
        var rawBody = await httpResponse.Content.ReadAsStringAsync();

        T? deserialized = default;
        if (!string.IsNullOrWhiteSpace(rawBody))
        {
            try
            {
                deserialized = JsonSerializer.Deserialize<T>(rawBody, JsonOptions);
            }
            catch (JsonException)
            {
                // Leave Body as default; RawBody still has the full payload for diagnostics.
            }
        }

        return new ApiResponse<T>
        {
            StatusCode = httpResponse.StatusCode,
            Body = deserialized,
            RawBody = rawBody,
            ElapsedMs = GetHeaderAsLong(httpResponse, "X-Kibo-Elapsed-Ms"),
            CorrelationId = GetHeader(httpResponse, "X-Kibo-Correlation-Id"),
            RequestLog = GetHeader(httpResponse, "X-Kibo-Request-Log"),
            ResponseLog = GetHeader(httpResponse, "X-Kibo-Response-Log"),
        };
    }

    private static string GetHeader(HttpResponseMessage response, string name)
        => response.Headers.TryGetValues(name, out var values) ? string.Join(" ", values) : string.Empty;

    private static long GetHeaderAsLong(HttpResponseMessage response, string name)
        => long.TryParse(GetHeader(response, name), out var value) ? value : 0;

    public void Dispose() => _httpClient.Dispose();
}
