namespace Kibo.TestingFramework.Models;

/// <summary>
/// Mirrors Kibo.MockApi.Models.Order. Used both for serializing
/// requests (CustomerEmail + LineItems) and deserializing responses
/// (which additionally populate Id, TenantId, and Status).
/// </summary>
public class Order
{
    public Guid Id { get; set; }

    public string TenantId { get; set; } = string.Empty;

    public string CustomerEmail { get; set; } = string.Empty;

    public string Status { get; set; } = "Pending";

    public List<LineItem> LineItems { get; set; } = new();
}

/// <summary>
/// Mirrors Kibo.MockApi.Models.LineItem.
/// </summary>
public class LineItem
{
    public string ProductCode { get; set; } = string.Empty;

    public int Quantity { get; set; }

    public decimal UnitPrice { get; set; }
}
