namespace Kibo.TestingFramework.Polling;

/// <summary>
/// Generic polling/wait-until utility for replacing brittle <c>Thread.Sleep</c>
/// calls with condition-based polling.
///
/// <code>
/// var readyOrder = await Poller.WaitUntilAsync(
///     action: () => client.GetOrderAsync(orderId),
///     condition: r => r.Body?.Status == "ReadyForFulfillment",
///     interval: TimeSpan.FromMilliseconds(500),
///     timeout: TimeSpan.FromSeconds(15));
/// </code>
/// </summary>
public static class Poller
{
    /// <summary>Default polling interval, used when none is supplied.</summary>
    public static readonly TimeSpan DefaultInterval = TimeSpan.FromMilliseconds(500);

    /// <summary>Default timeout, used when none is supplied.</summary>
    public static readonly TimeSpan DefaultTimeout = TimeSpan.FromSeconds(15);

    /// <summary>
    /// Repeatedly invokes <paramref name="action"/> until <paramref name="condition"/>
    /// returns true, or <paramref name="timeout"/> elapses.
    /// </summary>
    /// <typeparam name="T">The result type produced by <paramref name="action"/>.</typeparam>
    /// <param name="action">An async operation to invoke on each poll attempt.</param>
    /// <param name="condition">
    /// Predicate evaluated against the result of each <paramref name="action"/> call.
    /// Polling stops as soon as this returns true.
    /// </param>
    /// <param name="interval">
    /// Delay between poll attempts. Defaults to <see cref="DefaultInterval"/> (500ms).
    /// </param>
    /// <param name="timeout">
    /// Maximum time to keep polling before giving up. Defaults to
    /// <see cref="DefaultTimeout"/> (15s).
    /// </param>
    /// <returns>
    /// The result of <paramref name="action"/> as soon as <paramref name="condition"/>
    /// is satisfied — no unnecessary additional waiting.
    /// </returns>
    /// <exception cref="TimeoutException">
    /// Thrown if <paramref name="timeout"/> elapses before <paramref name="condition"/>
    /// is satisfied. The exception message includes the last observed result so the
    /// failure is self-diagnosing.
    /// </exception>
    public static async Task<T> WaitUntilAsync<T>(
        Func<Task<T>> action,
        Func<T, bool> condition,
        TimeSpan? interval = null,
        TimeSpan? timeout = null)
    {
        var pollInterval = interval ?? DefaultInterval;
        var pollTimeout = timeout ?? DefaultTimeout;

        using var cts = new CancellationTokenSource(pollTimeout);
        T last = await action();

        while (!condition(last))
        {
            if (cts.IsCancellationRequested)
            {
                throw new TimeoutException(
                    $"Polling timed out after {pollTimeout}. Last observed state: {Describe(last)}");
            }

            try
            {
                await Task.Delay(pollInterval, cts.Token);
            }
            catch (OperationCanceledException)
            {
                throw new TimeoutException(
                    $"Polling timed out after {pollTimeout}. Last observed state: {Describe(last)}");
            }

            last = await action();
        }

        return last;
    }

    /// <summary>
    /// Renders the last observed result for inclusion in a timeout exception
    /// message. Falls back to ToString() for types without a custom
    /// JSON-friendly representation.
    /// </summary>
    private static string Describe<T>(T value)
    {
        try
        {
            return System.Text.Json.JsonSerializer.Serialize(value);
        }
        catch
        {
            return value?.ToString() ?? "null";
        }
    }
}
