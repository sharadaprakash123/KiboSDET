using Kibo.TestingFramework.Models;

namespace Kibo.TestingFramework.Builders;

/// <summary>
/// Fluent builder for <see cref="Order"/> test data.
///
/// Produces a valid order with zero configuration via sensible defaults
/// (one random line item, a generated unique customer email). Each
/// <c>With*</c> method returns <c>this</c> for chaining, and <see cref="Build"/>
/// returns the constructed <see cref="Order"/>.
///
/// Example:
/// <code>
/// var order = new OrderBuilder()
///     .WithCustomerEmail("test@kibo.com")
///     .WithItems(2)
///     .ForTenant("tenant-xyz")
///     .Build();
/// </code>
/// </summary>
public class OrderBuilder
{
    private static readonly string[] SampleProductCodes =
    {
        "SKU-001", "SKU-002", "SKU-003", "SKU-042", "SKU-100", "SKU-256"
    };

    private static readonly Random Random = new();

    private string _customerEmail = $"test-{Guid.NewGuid():N}"[..16] + "@kibo.com";
    private string? _tenantId;
    private readonly List<LineItem> _lineItems = new();

    /// <summary>
    /// Sets the customer email. If never called, a unique generated
    /// email (e.g. "test-ab12cd34@kibo.com") is used.
    /// </summary>
    public OrderBuilder WithCustomerEmail(string email)
    {
        _customerEmail = email;
        return this;
    }

    /// <summary>
    /// Generates <paramref name="count"/> random line items with randomized
    /// product codes, quantities (1-5), and unit prices (1.00-199.99).
    /// Calling this clears any items added via <see cref="WithLineItem"/> or
    /// previous calls to <see cref="WithItems"/>.
    /// </summary>
    public OrderBuilder WithItems(int count)
    {
        _lineItems.Clear();
        for (var i = 0; i < count; i++)
        {
            _lineItems.Add(RandomLineItem());
        }
        return this;
    }

    /// <summary>
    /// Adds a single explicit line item. Useful for tests that need a
    /// specific product code, quantity, or price (e.g. negative pricing
    /// edge cases).
    /// </summary>
    public OrderBuilder WithLineItem(string productCode, int quantity, decimal unitPrice)
    {
        _lineItems.Add(new LineItem
        {
            ProductCode = productCode,
            Quantity = quantity,
            UnitPrice = unitPrice
        });
        return this;
    }

    /// <summary>
    /// Replaces all line items with an empty list. Useful for testing the
    /// "empty cart" edge case.
    /// </summary>
    public OrderBuilder WithNoItems()
    {
        _lineItems.Clear();
        return this;
    }

    /// <summary>
    /// Sets the tenant id to be used when the order is created
    /// (sent via the <c>x-kibo-tenant</c> header by <see cref="Client.ApiClient"/>,
    /// not as part of the JSON body).
    /// </summary>
    public OrderBuilder ForTenant(string tenantId)
    {
        _tenantId = tenantId;
        return this;
    }

    /// <summary>
    /// Builds the <see cref="Order"/>. If <see cref="WithItems"/> /
    /// <see cref="WithLineItem"/> was never called, one random line item
    /// is included so the result is valid with zero configuration.
    /// </summary>
    public Order Build()
    {
        var items = _lineItems.Count > 0
            ? _lineItems
            : new List<LineItem> { RandomLineItem() };

        return new Order
        {
            CustomerEmail = _customerEmail,
            TenantId = _tenantId ?? string.Empty,
            LineItems = items
        };
    }

    /// <summary>
    /// The tenant id configured via <see cref="ForTenant"/>, if any.
    /// Tests can read this to pass to <see cref="Client.ApiClient.CreateOrderAsync"/>.
    /// </summary>
    public string? TenantId => _tenantId;

    private static LineItem RandomLineItem() => new()
    {
        ProductCode = SampleProductCodes[Random.Next(SampleProductCodes.Length)],
        Quantity = Random.Next(1, 6),
        UnitPrice = Math.Round((decimal)(Random.NextDouble() * 198.99 + 1.00), 2)
    };
}
