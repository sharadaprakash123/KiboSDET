using System.Net;
using Kibo.TestingFramework.Builders;
using Kibo.TestingFramework.Client;

namespace Kibo.LegacyTests;

/// <summary>
/// Task 4 — AI-driven edge case tests.
///
/// These five scenarios were brainstormed with an LLM (see PROMPT_LOG.md, Prompt 4)
/// by analyzing the two MockApi endpoints (POST /v1/orders, GET /v1/orders/{id}) for
/// missing input validation. Each test documents the expected behavior for a
/// well-validated API and the actual behavior observed against Kibo.MockApi,
/// with a BUG REPORT comment where the actual behavior is a finding.
/// </summary>
public class EdgeCaseTests
{
    /// <summary>
    /// ***SECURITY BUG REPORT***
    /// CRITICAL: MockApi accepts a SQL-injection-shaped payload in the
    /// x-kibo-tenant header with no validation or sanitization.
    /// Payload: "tenant1'; DROP TABLE Orders; --"
    /// Expected: 400 Bad Request (header should be validated against an
    ///           allow-listed format, e.g. alphanumeric + hyphens only).
    /// Actual:   201 Created — the header is stored verbatim as TenantId.
    /// Risk:     If TenantId is ever interpolated into a SQL query or log
    ///           sink without parameterization, this is a direct injection
    ///           vector and/or log-injection vector.
    /// Recommendation: Validate x-kibo-tenant against an allow-listed
    ///           pattern (e.g. ^[a-zA-Z0-9-]{1,64}$) and reject anything else
    ///           with 400 Bad Request before it reaches the data layer.
    /// </summary>
    [Fact]
    public async Task CreateOrder_SqlInjectionTenantHeader_AcceptsMaliciousPayload()
    {
        const string maliciousTenant = "tenant1'; DROP TABLE Orders; --";
        using var client = ApiClient.CreateClientWithTenant(maliciousTenant);

        var order = new OrderBuilder()
            .WithCustomerEmail("sqli@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        // Documents actual (vulnerable) behavior: MockApi accepts the payload.
        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
        Assert.Equal(maliciousTenant, response.Body?.TenantId);
    }

    /// <summary>
    /// ***BUG REPORT***
    /// Scenario: customerEmail containing Unicode/special characters that are
    /// valid in some email implementations but commonly used in XSS payloads
    /// (e.g. "&lt;script&gt;" tags, right-to-left override characters).
    /// Payload: "&lt;script&gt;alert(1)&lt;/script&gt;@example.com"
    /// Expected: 400 Bad Request (invalid email format should be rejected).
    /// Actual:   201 Created — no email format validation is performed; the
    ///           raw string is stored and echoed back verbatim.
    /// Risk:     If CustomerEmail is ever rendered in an admin dashboard or
    ///           email template without escaping, this is a stored-XSS vector.
    /// Recommendation: Validate customerEmail against a standard email regex
    ///           and reject non-conforming values with 400 Bad Request.
    /// </summary>
    [Fact]
    public async Task CreateOrder_UnicodeXssCustomerEmail_AcceptsMaliciousPayload()
    {
        using var client = new ApiClient();

        var order = new OrderBuilder()
            .WithCustomerEmail("<script>alert(1)</script>@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
        Assert.Equal("<script>alert(1)</script>@example.com", response.Body?.CustomerEmail);
    }

    /// <summary>
    /// ***BUG REPORT***
    /// Scenario: an order submitted with an empty lineItems array.
    /// Expected: 400 Bad Request — an order with no items is not a valid
    ///           business object and should be rejected at the API boundary.
    /// Actual:   201 Created — an "empty" order is persisted with Status =
    ///           "Pending" and zero line items.
    /// Risk:     Empty orders pollute downstream fulfillment/reporting systems
    ///           and may indicate a client-side bug going undetected.
    /// Recommendation: Reject orders where lineItems is null or empty with
    ///           400 Bad Request and a descriptive error message.
    /// </summary>
    [Fact]
    public async Task CreateOrder_EmptyLineItems_AcceptsEmptyOrder()
    {
        using var client = new ApiClient();

        var order = new OrderBuilder()
            .WithCustomerEmail("empty-cart@example.com")
            .WithNoItems()
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
        Assert.Empty(response.Body?.LineItems ?? new());
    }

    /// <summary>
    /// ***BUG REPORT***
    /// Scenario: an order containing a line item with a negative unit price.
    /// Expected: 400 Bad Request — negative pricing is never valid and
    ///           represents either a client bug or an attempted financial
    ///           manipulation (e.g. negative-total "refund via checkout").
    /// Actual:   201 Created — the negative price is accepted and persisted
    ///           verbatim.
    /// Risk:     Direct financial risk if any downstream total/invoice
    ///           calculation trusts this value.
    /// Recommendation: Validate unitPrice >= 0 (and quantity > 0) server-side
    ///           and reject violations with 400 Bad Request.
    /// </summary>
    [Fact]
    public async Task CreateOrder_NegativeUnitPrice_AcceptsInvalidPricing()
    {
        using var client = new ApiClient();

        var order = new OrderBuilder()
            .WithCustomerEmail("negative-price@example.com")
            .WithLineItem("SKU-NEG", quantity: 1, unitPrice: -50.00m)
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
        Assert.Equal(-50.00m, response.Body?.LineItems.FirstOrDefault()?.UnitPrice);
    }

    /// <summary>
    /// ***BUG REPORT***
    /// Scenario: a request body with an oversized customerEmail field
    /// (10,000 characters) — a basic denial-of-service / buffer-stress probe.
    /// Expected: 400 Bad Request or 413 Payload Too Large — fields should
    ///           have enforced maximum lengths.
    /// Actual:   201 Created — the oversized string is accepted and echoed
    ///           back in full, with no apparent length limit.
    /// Risk:     Repeated oversized payloads could be used to inflate storage
    ///           or degrade performance of any system that persists/indexes
    ///           CustomerEmail without a length cap.
    /// Recommendation: Enforce a reasonable max length (e.g. 254 chars per
    ///           RFC 5321) on customerEmail and similar string fields, and
    ///           return 400 Bad Request for violations.
    /// </summary>
    [Fact]
    public async Task CreateOrder_OversizedCustomerEmail_AcceptsWithoutLengthLimit()
    {
        using var client = new ApiClient();

        var oversizedLocalPart = new string('a', 10_000);
        var order = new OrderBuilder()
            .WithCustomerEmail($"{oversizedLocalPart}@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
        Assert.Equal(10_000 + "@example.com".Length, response.Body?.CustomerEmail.Length);
    }

    /// <summary>
    /// Scenario: missing required field — request body omits "lineItems"
    /// entirely (not just empty, but absent from the JSON).
    /// Expected: 400 Bad Request or 201 Created with lineItems defaulting
    ///           to an empty list (model binding default).
    /// Actual:   201 Created — ASP.NET Core model binding falls back to the
    ///           Order.LineItems default (empty List&lt;LineItem&gt;), so this
    ///           behaves identically to the explicit-empty-array case (see
    ///           CreateOrder_EmptyLineItems_AcceptsEmptyOrder above).
    /// Note: Not flagged as a new bug — it's the same root cause as the
    ///           empty-lineItems finding, included here to confirm the model
    ///           binder doesn't reject the request outright (e.g. with a
    ///           "required member" validation error).
    /// </summary>
    [Fact]
    public async Task CreateOrder_MissingLineItemsField_FallsBackToEmptyList()
    {
        using var client = new ApiClient();

        const string rawJsonWithoutLineItems = """
        {
            "customerEmail": "missing-field@example.com"
        }
        """;

        var response = await client.CreateOrderRawAsync(rawJsonWithoutLineItems);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
        Assert.Empty(response.Body?.LineItems ?? new());
    }
}
