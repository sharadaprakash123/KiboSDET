using System.Net;
using Kibo.TestingFramework.Builders;
using Kibo.TestingFramework.Client;

namespace Kibo.LegacyTests;

/// <summary>
/// Task 6 — demonstrates the observability features of <see cref="ApiClient"/>:
/// every <see cref="Kibo.TestingFramework.Observability.ApiResponse{T}"/> carries
/// timing, a correlation id, and request/response logs, all available without
/// re-running the test.
/// </summary>
public class ObservabilityTests
{
    [Fact]
    public async Task CreateOrder_RespondsWithinExpectedTime()
    {
        using var client = new ApiClient();

        var order = new OrderBuilder()
            .WithCustomerEmail("perf-check@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());

        // Timing is captured automatically on every call.
        Console.WriteLine($"CreateOrder took {response.ElapsedMs}ms");

        // Generous bound for a local mock API — guards against major regressions
        // without being flaky on slower CI runners.
        Assert.True(
            response.ElapsedMs < 2000,
            $"Expected order creation to respond within 2000ms, took {response.ElapsedMs}ms. " +
            response.ToDiagnosticString());
    }

    [Fact]
    public async Task CreateOrder_DiagnosticsIncludeCorrelationIdAndLogs()
    {
        using var client = new ApiClient();

        var order = new OrderBuilder()
            .WithCustomerEmail("diagnostics-check@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        // Every response carries a correlation id and human-readable
        // request/response logs, independent of the console-logging toggle.
        Assert.NotEmpty(response.CorrelationId);
        Assert.Contains("POST", response.RequestLog);
        Assert.Contains(response.CorrelationId, response.RequestLog);
        Assert.Contains(response.CorrelationId, response.ResponseLog);
    }

    [Fact]
    public async Task EnableConsoleLogging_PrintsRequestAndResponseDiagnostics()
    {
        // Logging is off by default for clean test output, but can be toggled
        // per-client (or globally via KIBO_TEST_LOGGING=true).
        using var client = new ApiClient { EnableConsoleLogging = true };

        var order = new OrderBuilder()
            .WithCustomerEmail("console-logging@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
    }
}
