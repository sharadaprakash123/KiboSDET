using System.Net;
using Kibo.TestingFramework.Builders;
using Kibo.TestingFramework.Client;
using Kibo.TestingFramework.Polling;

namespace Kibo.LegacyTests;

/// <summary>
/// Refactored from the original "legacy" OrderTests.
///
/// Anti-patterns removed:
///   • No more per-test HttpClient — <see cref="ApiClient"/> owns a single
///     HttpClient with proper lifecycle/disposal (IDisposable, used via `using`).
///   • No hardcoded "http://localhost:5000" — base URL comes from
///     KIBO_API_BASE_URL (with a localhost fallback inside ApiClient).
///   • No duplicated x-kibo-tenant header logic — handled centrally by ApiClient.
///   • No raw inline JSON strings — <see cref="OrderBuilder"/> constructs typed
///     Order objects.
///   • No Thread.Sleep(6000) — replaced with <see cref="Poller.WaitUntilAsync{T}"/>.
/// </summary>
public class OrderTests
{
    [Fact]
    public async Task CreateOrder_ReturnsSuccess()
    {
        using var client = new ApiClient();

        var order = new OrderBuilder()
            .WithCustomerEmail("john.doe@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Created, response.ToDiagnosticString());
        Assert.Equal("Pending", response.Body?.Status);
    }

    [Fact]
    public async Task CreateOrder_WithoutTenantHeader_Returns401()
    {
        // Construct a client that deliberately sends no x-kibo-tenant header.
        using var client = ApiClient.WithoutTenantHeader();

        var order = new OrderBuilder()
            .WithCustomerEmail("no-tenant@example.com")
            .WithItems(1)
            .Build();

        var response = await client.CreateOrderAsync(order);

        Assert.True(response.StatusCode == HttpStatusCode.Unauthorized, response.ToDiagnosticString());
    }

    [Fact]
    public async Task GetOrder_AfterCreation_StatusBecomesReadyForFulfillment()
    {
        using var client = new ApiClient();

        var order = new OrderBuilder()
            .WithCustomerEmail("status-check@example.com")
            .WithItems(1)
            .Build();

        var createResponse = await client.CreateOrderAsync(order);
        Assert.True(createResponse.StatusCode == HttpStatusCode.Created, createResponse.ToDiagnosticString());

        var orderId = createResponse.Body!.Id;

        // Replaces Thread.Sleep(6000): poll until the status flips, returning
        // as soon as it does (typically just after the 5s server-side delay)
        // and failing fast with the last observed status if it never does.
        var readyResponse = await Poller.WaitUntilAsync(
            action: () => client.GetOrderAsync(orderId),
            condition: r => r.Body?.Status == "ReadyForFulfillment",
            interval: TimeSpan.FromMilliseconds(500),
            timeout: TimeSpan.FromSeconds(15));

        Assert.Equal("ReadyForFulfillment", readyResponse.Body?.Status);
    }

    [Fact]
    public async Task GetOrder_WithInvalidId_Returns404()
    {
        using var client = new ApiClient();

        var response = await client.GetOrderAsync(Guid.NewGuid());

        Assert.True(response.StatusCode == HttpStatusCode.NotFound, response.ToDiagnosticString());
    }
}
